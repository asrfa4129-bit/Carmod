package com.carmod;

import java.util.function.Supplier;

import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

public class CarActionPacket {
    public static final int HORN = 0;
    public static final int LIGHTS = 1;

    private final int action;

    public CarActionPacket(int action) {
        this.action = action;
    }

    public static void encode(CarActionPacket p, FriendlyByteBuf buf) {
        buf.writeByte(p.action);
    }

    public static CarActionPacket decode(FriendlyByteBuf buf) {
        return new CarActionPacket(buf.readByte());
    }

    public static void handle(CarActionPacket p, Supplier<NetworkEvent.Context> ctx) {
        NetworkEvent.Context c = ctx.get();
        c.enqueueWork(() -> {
            ServerPlayer player = c.getSender();
            if (player != null && player.getVehicle() instanceof CarEntity car
                    && car.getControllingPassenger() == player) {
                if (p.action == HORN) car.honk();
                else if (p.action == LIGHTS) car.toggleLights();
            }
        });
        c.setPacketHandled(true);
    }
}
