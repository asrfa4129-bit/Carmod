package com.carmod;

import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, CarMod.MODID);

    public static final RegistryObject<Item> CAR = ITEMS.register("car",
            () -> new CarItem(new Item.Properties().stacksTo(1)));
}
