package com.carmod;

import net.minecraft.client.KeyMapping;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = CarMod.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    public static final KeyMapping HORN =
            new KeyMapping("key.carmod.horn", GLFW.GLFW_KEY_H, "key.categories.carmod");
    public static final KeyMapping LIGHTS =
            new KeyMapping("key.carmod.lights", GLFW.GLFW_KEY_G, "key.categories.carmod");

    @SubscribeEvent
    public static void keys(RegisterKeyMappingsEvent e) {
        e.register(HORN);
        e.register(LIGHTS);
    }

    @SubscribeEvent
    public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e) {
        e.registerLayerDefinition(CarRenderer.LAYER, CarModel::createBodyLayer);
    }

    @SubscribeEvent
    public static void renderers(EntityRenderersEvent.RegisterRenderers e) {
        e.registerEntityRenderer(ModEntities.CAR.get(), CarRenderer::new);
    }
}
