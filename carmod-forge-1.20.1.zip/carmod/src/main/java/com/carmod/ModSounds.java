package com.carmod;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {
    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(ForgeRegistries.SOUND_EVENTS, CarMod.MODID);

    public static final RegistryObject<SoundEvent> HORN = SOUNDS.register("horn",
            () -> SoundEvent.createVariableRangeEvent(new ResourceLocation(CarMod.MODID, "horn")));
}
