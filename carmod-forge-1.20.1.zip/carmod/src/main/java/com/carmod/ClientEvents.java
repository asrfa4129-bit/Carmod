package com.carmod;

import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = CarMod.MODID, bus = Mod.EventBusSubscriber.Bus.FORGE, value = Dist.CLIENT)
public class ClientEvents {
    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.screen != null) return;
        if (!(mc.player.getVehicle() instanceof CarEntity car)) return;
        if (car.getControllingPassenger() != mc.player) return;

        if (ClientSetup.HORN.isDown()) {
            ModNetwork.CHANNEL.sendToServer(new CarActionPacket(CarActionPacket.HORN));
        }
        while (ClientSetup.LIGHTS.consumeClick()) {
            ModNetwork.CHANNEL.sendToServer(new CarActionPacket(CarActionPacket.LIGHTS));
        }
    }
}
