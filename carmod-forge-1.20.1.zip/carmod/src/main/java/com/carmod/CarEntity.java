package com.carmod;

import javax.annotation.Nullable;

import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

public class CarEntity extends Entity {
    private static final EntityDataAccessor<Integer> FUEL =
            SynchedEntityData.defineId(CarEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> LIGHTS =
            SynchedEntityData.defineId(CarEntity.class, EntityDataSerializers.BOOLEAN);

    public static final int MAX_FUEL = 1000;
    private static final int START_FUEL = 300;
    private static final double FUEL_PER_BLOCK = 0.25;

    private static final float MAX_SPEED = 0.8F;     // blocks per tick (16 blocks/s)
    private static final float MAX_REVERSE = 0.25F;
    private static final float ACCEL = 0.03F;
    private static final float BRAKE = 0.06F;
    private static final float COAST = 0.95F;

    // Seat layout (tweak SEAT_FEET_Y if riders look too high or low)
    private static final double SEAT_FEET_Y = -0.2;
    private static final double SEAT_SIDE = 0.3;
    private static final double SEAT_FORWARD = -0.15;

    private float speed;
    private int hornCooldown;
    private double fuelBuffer;
    private float kmh;

    // interpolation for remote clients
    private int lerpSteps;
    private double lerpX, lerpY, lerpZ;
    private double lerpYRot;

    // client visuals
    public float wheelRoll, wheelRollO, steerAngle, steerAngleO;

    public CarEntity(EntityType<? extends CarEntity> type, Level level) {
        super(type, level);
        this.blocksBuilding = true;
        this.entityData.set(FUEL, START_FUEL);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(FUEL, 0);
        this.entityData.define(LIGHTS, false);
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        setFuel(tag.getInt("Fuel"));
        this.entityData.set(LIGHTS, tag.getBoolean("Lights"));
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Fuel", getFuel());
        tag.putBoolean("Lights", hasLights());
    }

    @Override
    public Packet<ClientGamePacketListener> getAddEntityPacket() {
        return NetworkHooks.getEntitySpawningPacket(this);
    }

    public int getFuel() {
        return this.entityData.get(FUEL);
    }

    public void setFuel(int fuel) {
        this.entityData.set(FUEL, Mth.clamp(fuel, 0, MAX_FUEL));
    }

    public boolean hasLights() {
        return this.entityData.get(LIGHTS);
    }

    // ---------- actions (server side) ----------

    public void honk() {
        if (hornCooldown > 0) return;
        hornCooldown = 12;
        level().playSound(null, getX(), getY(), getZ(), ModSounds.HORN.get(), SoundSource.NEUTRAL, 1.6F, 1.0F);
    }

    public void toggleLights() {
        this.entityData.set(LIGHTS, !hasLights());
        level().playSound(null, getX(), getY(), getZ(), SoundEvents.LEVER_CLICK, SoundSource.NEUTRAL, 0.6F, 1.4F);
    }

    // ---------- basic entity setup ----------

    @Override
    public boolean isPickable() {
        return !isRemoved();
    }

    @Override
    public boolean canBeCollidedWith() {
        return true;
    }

    @Override
    protected MovementEmission getMovementEmission() {
        return MovementEmission.NONE;
    }

    @Override
    public ItemStack getPickResult() {
        return new ItemStack(ModItems.CAR.get());
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (isInvulnerableTo(source)) return false;
        if (level().isClientSide || isRemoved()) return true;
        if (source.getEntity() instanceof Player player) {
            if (!player.getAbilities().instabuild) {
                spawnAtLocation(ModItems.CAR.get());
            }
            discard();
        }
        return true;
    }

    // ---------- interaction: refuel / board ----------

    private static int fuelValue(ItemStack s) {
        if (s.is(Items.COAL) || s.is(Items.CHARCOAL)) return 100;
        if (s.is(Items.BLAZE_ROD)) return 160;
        if (s.is(Items.LAVA_BUCKET)) return 700;
        if (s.is(Items.COAL_BLOCK)) return 900;
        return 0;
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        int add = fuelValue(stack);
        if (add > 0 && getFuel() < MAX_FUEL) {
            if (!level().isClientSide) {
                setFuel(getFuel() + add);
                if (!player.getAbilities().instabuild) {
                    if (stack.is(Items.LAVA_BUCKET)) {
                        player.setItemInHand(hand, new ItemStack(Items.BUCKET));
                    } else {
                        stack.shrink(1);
                    }
                }
                level().playSound(null, getX(), getY(), getZ(), SoundEvents.FIRECHARGE_USE, SoundSource.NEUTRAL, 0.8F, 1.0F);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        if (player.isSecondaryUseActive()) {
            return InteractionResult.PASS;
        }
        if (!level().isClientSide) {
            return player.startRiding(this) ? InteractionResult.CONSUME : InteractionResult.PASS;
        }
        return InteractionResult.SUCCESS;
    }

    // ---------- passengers ----------

    @Override
    protected boolean canAddPassenger(Entity passenger) {
        return getPassengers().size() < 2;
    }

    @Nullable
    @Override
    public LivingEntity getControllingPassenger() {
        return getFirstPassenger() instanceof Player p ? p : null;
    }

    @Override
    protected void positionRider(Entity passenger, MoveFunction callback) {
        if (!hasPassenger(passenger)) return;
        int idx = getPassengers().indexOf(passenger);
        float yaw = getYRot() * Mth.DEG_TO_RAD;
        double side = idx == 0 ? SEAT_SIDE : -SEAT_SIDE;
        double fwd = SEAT_FORWARD;
        double x = getX() + (-Mth.sin(yaw) * fwd) + (Mth.cos(yaw) * side);
        double z = getZ() + (Mth.cos(yaw) * fwd) + (Mth.sin(yaw) * side);
        callback.accept(passenger, x, getY() + SEAT_FEET_Y, z);
        clampRotation(passenger);
    }

    protected void clampRotation(Entity entity) {
        entity.setYBodyRot(getYRot());
        float diff = Mth.wrapDegrees(entity.getYRot() - getYRot());
        float clamped = Mth.clamp(diff, -105.0F, 105.0F);
        entity.yRotO += clamped - diff;
        entity.setYRot(entity.getYRot() + clamped - diff);
        entity.setYHeadRot(entity.getYRot());
    }

    @Override
    public void onPassengerTurned(Entity entity) {
        clampRotation(entity);
    }

    @Override
    public Vec3 getDismountLocationForPassenger(LivingEntity passenger) {
        int idx = getPassengers().indexOf(passenger);
        float yaw = getYRot() * Mth.DEG_TO_RAD;
        double s = idx == 1 ? -1.7 : 1.7;
        double[][] tries = { { s, 0 }, { -s, 0 }, { 0, 2.0 }, { 0, -2.2 } };
        for (double[] t : tries) {
            double x = getX() + Mth.cos(yaw) * t[0] - Mth.sin(yaw) * t[1];
            double z = getZ() + Mth.sin(yaw) * t[0] + Mth.cos(yaw) * t[1];
            double y = getY() + 0.1;
            if (level().noCollision(passenger, passenger.getDimensions(Pose.STANDING).makeBoundingBox(x, y, z))) {
                return new Vec3(x, y, z);
            }
        }
        return super.getDismountLocationForPassenger(passenger);
    }

    // ---------- interpolation (other players' view) ----------

    @Override
    public void lerpTo(double x, double y, double z, float yRot, float xRot, int steps, boolean teleport) {
        this.lerpX = x;
        this.lerpY = y;
        this.lerpZ = z;
        this.lerpYRot = yRot;
        this.lerpSteps = 10;
    }

    private void tickLerp() {
        if (isControlledByLocalInstance()) {
            this.lerpSteps = 0;
            syncPacketPositionCodec(getX(), getY(), getZ());
        }
        if (this.lerpSteps > 0) {
            double nx = getX() + (lerpX - getX()) / lerpSteps;
            double ny = getY() + (lerpY - getY()) / lerpSteps;
            double nz = getZ() + (lerpZ - getZ()) / lerpSteps;
            double dyaw = Mth.wrapDegrees(lerpYRot - getYRot());
            setYRot(getYRot() + (float) dyaw / lerpSteps);
            lerpSteps--;
            setPos(nx, ny, nz);
            setRot(getYRot(), getXRot());
        }
    }

    // ---------- main loop ----------

    @Override
    public void tick() {
        double movedX = getX() - xo;
        double movedZ = getZ() - zo;
        super.tick();
        tickLerp();

        boolean server = !level().isClientSide;
        if (hornCooldown > 0) hornCooldown--;

        if (isControlledByLocalInstance() || (server && getControllingPassenger() == null)) {
            float before = getYRot();
            drive();
            float turned = getYRot() - before;
            if (turned != 0.0F && level().isClientSide) {
                for (Entity p : getPassengers()) {
                    p.setYRot(p.getYRot() + turned);
                    p.setYHeadRot(p.getYHeadRot() + turned);
                }
            }
        } else {
            setDeltaMovement(Vec3.ZERO);
        }

        if (server) {
            double dist = Math.sqrt(movedX * movedX + movedZ * movedZ);
            kmh = kmh * 0.8F + (float) (dist * 72.0) * 0.2F;
            LivingEntity driver = getControllingPassenger();
            if (driver != null) {
                fuelBuffer += dist * FUEL_PER_BLOCK;
                if (fuelBuffer >= 1.0) {
                    int use = (int) fuelBuffer;
                    fuelBuffer -= use;
                    setFuel(getFuel() - use);
                }
                if (driver instanceof ServerPlayer sp && tickCount % 4 == 0) {
                    sp.displayClientMessage(statusLine(), true);
                }
            }
        } else {
            updateVisuals();
        }
    }

    private Component statusLine() {
        int f = getFuel();
        int filled = Math.round(10.0F * f / MAX_FUEL);
        ChatFormatting color = f > MAX_FUEL * 0.3 ? ChatFormatting.GREEN
                : f > MAX_FUEL * 0.1 ? ChatFormatting.YELLOW : ChatFormatting.RED;
        MutableComponent bar = Component.literal("\u2588".repeat(filled)).withStyle(color)
                .append(Component.literal("\u2591".repeat(10 - filled)).withStyle(ChatFormatting.DARK_GRAY));
        return Component.translatable("hud.carmod.status", bar, Math.round(kmh),
                Component.translatable(hasLights() ? "hud.carmod.on" : "hud.carmod.off"));
    }

    private void updateVisuals() {
        double mx = getX() - xo;
        double mz = getZ() - zo;
        float yawRad = getYRot() * Mth.DEG_TO_RAD;
        double fwd = mx * -Mth.sin(yawRad) + mz * Mth.cos(yawRad);
        wheelRollO = wheelRoll;
        wheelRoll += (float) (fwd / 0.3125);
        steerAngleO = steerAngle;
        float dyaw = Mth.wrapDegrees(getYRot() - yRotO);
        float target = Mth.clamp(dyaw * 0.12F, -0.6F, 0.6F);
        steerAngle = Mth.lerp(0.4F, steerAngle, target);
    }

    private void drive() {
        LivingEntity driver = getControllingPassenger();
        float throttle = driver != null ? driver.zza : 0.0F;
        float steerIn = driver != null ? driver.xxa : 0.0F;
        boolean hasFuel = getFuel() > 0;

        if (throttle > 0.01F && hasFuel) {
            speed = Math.min(speed + ACCEL * (1.2F - speed / MAX_SPEED), MAX_SPEED);
        } else if (throttle < -0.01F) {
            if (speed > 0.02F) {
                speed = Math.max(speed - BRAKE, 0.0F);
            } else if (hasFuel) {
                speed = Math.max(speed - ACCEL * 0.6F, -MAX_REVERSE);
            } else {
                speed *= COAST;
            }
        } else {
            speed *= driver == null ? 0.85F : COAST;
        }
        if (Math.abs(speed) < 0.004F) speed = 0.0F;

        if (steerIn != 0.0F && speed != 0.0F) {
            float grip = Mth.clamp(Math.abs(speed) / 0.2F, 0.0F, 1.0F);
            float rate = 6.0F - 3.5F * Math.abs(speed) / MAX_SPEED;
            setYRot(getYRot() - steerIn * rate * grip * Math.signum(speed));
        }

        float yawRad = getYRot() * Mth.DEG_TO_RAD;
        double vy = getDeltaMovement().y;
        if (isInWater()) {
            vy = Math.min(vy + 0.05, 0.12);
            speed *= 0.93F;
        } else {
            vy -= 0.08;
            vy *= 0.98;
        }
        setDeltaMovement(-Mth.sin(yawRad) * speed, vy, Mth.cos(yawRad) * speed);
        move(MoverType.SELF, getDeltaMovement());

        if (horizontalCollision) {
            if (onGround() && Math.abs(speed) > 0.05F && canHop(yawRad)) {
                Vec3 d = getDeltaMovement();
                setDeltaMovement(d.x, 0.42, d.z);
                speed *= 0.9F;
            } else {
                speed *= 0.5F;
            }
        }
    }

    private boolean canHop(float yawRad) {
        double dir = Math.signum(speed) * 0.8;
        double fx = -Mth.sin(yawRad) * dir;
        double fz = Mth.cos(yawRad) * dir;
        return level().noCollision(this, getBoundingBox().move(fx, 1.05, fz));
    }
}
