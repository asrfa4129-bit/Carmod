package com.carmod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class CarRenderer extends EntityRenderer<CarEntity> {
    public static final ModelLayerLocation LAYER =
            new ModelLayerLocation(new ResourceLocation(CarMod.MODID, "car"), "main");
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(CarMod.MODID, "textures/entity/car.png");
    private static final ResourceLocation TEXTURE_LIGHTS =
            new ResourceLocation(CarMod.MODID, "textures/entity/car_lights.png");

    private final CarModel model;

    public CarRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.9F;
        this.model = new CarModel(ctx.bakeLayer(LAYER));
    }

    @Override
    public ResourceLocation getTextureLocation(CarEntity car) {
        return TEXTURE;
    }

    @Override
    public void render(CarEntity car, float entityYaw, float partialTick, PoseStack ps,
                       MultiBufferSource buffers, int light) {
        ps.pushPose();
        ps.mulPose(Axis.YP.rotationDegrees(180.0F - entityYaw));
        ps.scale(-1.0F, -1.0F, 1.0F);
        ps.translate(0.0D, -1.501D, 0.0D);

        model.setWheels(Mth.lerp(partialTick, car.wheelRollO, car.wheelRoll),
                Mth.lerp(partialTick, car.steerAngleO, car.steerAngle));

        VertexConsumer body = buffers.getBuffer(RenderType.entityCutoutNoCull(TEXTURE));
        model.render(ps, body, light, OverlayTexture.NO_OVERLAY);

        if (car.hasLights()) {
            VertexConsumer glow = buffers.getBuffer(RenderType.eyes(TEXTURE_LIGHTS));
            model.render(ps, glow, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY);
        }
        ps.popPose();
        super.render(car, entityYaw, partialTick, ps, buffers, light);
    }
}
