# Car Mod (Forge 1.20.1)

## Kurulum / derleme
1. Forge 1.20.1 (47.3.0) MDK'sını indir ve içinden `gradlew`, `gradlew.bat` ve `gradle/` klasörünü bu klasöre kopyala.
2. JDK 17 kurulu olsun.
3. `./gradlew build` → jar: `build/libs/carmod-1.0.0.jar` → `mods` klasörüne at.
   Denemek için: `./gradlew runClient`

## Oynanış
- Tarif: demir x5, cam panel, redstone, siyah yün x2 (veya yaratıcı modda Tools sekmesi).
- Yere sağ tıkla → araba çıkar. Arabaya sağ tıkla → bin (2 kişilik).
- W/S gaz-fren-geri, A/D direksiyon, Shift = in.
- H = korna (basılı tut), G = farlar.
- Yakıt: arabaya kömür / odun kömürü / blaze rod / lav kovası / kömür bloğu ile sağ tıkla.
- Vurarak kır, araba geri düşer.
